﻿namespace AppSimProva_MatheusRuas_2b1
{
    partial class FmrQuestao3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlcabecalho = new System.Windows.Forms.Panel();
            this.pnlesquerda = new System.Windows.Forms.Panel();
            this.pnldireita = new System.Windows.Forms.Panel();
            this.txtprod1 = new System.Windows.Forms.TextBox();
            this.txtprod2 = new System.Windows.Forms.TextBox();
            this.txtprod3 = new System.Windows.Forms.TextBox();
            this.txtp1 = new System.Windows.Forms.TextBox();
            this.txtp3 = new System.Windows.Forms.TextBox();
            this.txtp2 = new System.Windows.Forms.TextBox();
            this.lblloja = new System.Windows.Forms.Label();
            this.lblprod1 = new System.Windows.Forms.Label();
            this.lblprod2 = new System.Windows.Forms.Label();
            this.lblprod3 = new System.Windows.Forms.Label();
            this.lblp1 = new System.Windows.Forms.Label();
            this.lblp2 = new System.Windows.Forms.Label();
            this.lblp3 = new System.Windows.Forms.Label();
            this.bntcalc = new System.Windows.Forms.Button();
            this.lblparcela1 = new System.Windows.Forms.Label();
            this.lblparcela2 = new System.Windows.Forms.Label();
            this.lblparcela3 = new System.Windows.Forms.Label();
            this.lblparcela4 = new System.Windows.Forms.Label();
            this.lblparcela5 = new System.Windows.Forms.Label();
            this.lblresult1 = new System.Windows.Forms.Label();
            this.lblresult2 = new System.Windows.Forms.Label();
            this.lblresult3 = new System.Windows.Forms.Label();
            this.lblresult4 = new System.Windows.Forms.Label();
            this.lblresult5 = new System.Windows.Forms.Label();
            this.pnlcabecalho.SuspendLayout();
            this.pnlesquerda.SuspendLayout();
            this.pnldireita.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlcabecalho
            // 
            this.pnlcabecalho.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pnlcabecalho.Controls.Add(this.lblloja);
            this.pnlcabecalho.Location = new System.Drawing.Point(-3, 2);
            this.pnlcabecalho.Name = "pnlcabecalho";
            this.pnlcabecalho.Size = new System.Drawing.Size(809, 122);
            this.pnlcabecalho.TabIndex = 0;
            // 
            // pnlesquerda
            // 
            this.pnlesquerda.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlesquerda.Controls.Add(this.lblp3);
            this.pnlesquerda.Controls.Add(this.lblprod3);
            this.pnlesquerda.Controls.Add(this.lblp2);
            this.pnlesquerda.Controls.Add(this.lblp1);
            this.pnlesquerda.Controls.Add(this.lblprod2);
            this.pnlesquerda.Controls.Add(this.lblprod1);
            this.pnlesquerda.Controls.Add(this.txtp3);
            this.pnlesquerda.Controls.Add(this.txtprod3);
            this.pnlesquerda.Controls.Add(this.txtp1);
            this.pnlesquerda.Controls.Add(this.txtp2);
            this.pnlesquerda.Controls.Add(this.txtprod2);
            this.pnlesquerda.Controls.Add(this.txtprod1);
            this.pnlesquerda.Location = new System.Drawing.Point(2, 132);
            this.pnlesquerda.Name = "pnlesquerda";
            this.pnlesquerda.Size = new System.Drawing.Size(381, 260);
            this.pnlesquerda.TabIndex = 1;
            // 
            // pnldireita
            // 
            this.pnldireita.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnldireita.Controls.Add(this.lblresult5);
            this.pnldireita.Controls.Add(this.lblresult4);
            this.pnldireita.Controls.Add(this.lblresult3);
            this.pnldireita.Controls.Add(this.lblresult2);
            this.pnldireita.Controls.Add(this.lblresult1);
            this.pnldireita.Controls.Add(this.lblparcela5);
            this.pnldireita.Controls.Add(this.lblparcela4);
            this.pnldireita.Controls.Add(this.lblparcela3);
            this.pnldireita.Controls.Add(this.lblparcela2);
            this.pnldireita.Controls.Add(this.lblparcela1);
            this.pnldireita.Location = new System.Drawing.Point(402, 132);
            this.pnldireita.Name = "pnldireita";
            this.pnldireita.Size = new System.Drawing.Size(392, 259);
            this.pnldireita.TabIndex = 2;
            // 
            // txtprod1
            // 
            this.txtprod1.Location = new System.Drawing.Point(40, 60);
            this.txtprod1.Name = "txtprod1";
            this.txtprod1.Size = new System.Drawing.Size(100, 20);
            this.txtprod1.TabIndex = 0;
            this.txtprod1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtprod2
            // 
            this.txtprod2.Location = new System.Drawing.Point(40, 112);
            this.txtprod2.Name = "txtprod2";
            this.txtprod2.Size = new System.Drawing.Size(100, 20);
            this.txtprod2.TabIndex = 0;
            this.txtprod2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtprod3
            // 
            this.txtprod3.Location = new System.Drawing.Point(40, 167);
            this.txtprod3.Name = "txtprod3";
            this.txtprod3.Size = new System.Drawing.Size(100, 20);
            this.txtprod3.TabIndex = 0;
            this.txtprod3.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtp1
            // 
            this.txtp1.Location = new System.Drawing.Point(206, 60);
            this.txtp1.Name = "txtp1";
            this.txtp1.Size = new System.Drawing.Size(100, 20);
            this.txtp1.TabIndex = 0;
            this.txtp1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtp3
            // 
            this.txtp3.Location = new System.Drawing.Point(206, 167);
            this.txtp3.Name = "txtp3";
            this.txtp3.Size = new System.Drawing.Size(100, 20);
            this.txtp3.TabIndex = 0;
            this.txtp3.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtp2
            // 
            this.txtp2.Location = new System.Drawing.Point(206, 112);
            this.txtp2.Name = "txtp2";
            this.txtp2.Size = new System.Drawing.Size(100, 20);
            this.txtp2.TabIndex = 0;
            this.txtp2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblloja
            // 
            this.lblloja.AutoSize = true;
            this.lblloja.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloja.Location = new System.Drawing.Point(39, 46);
            this.lblloja.Name = "lblloja";
            this.lblloja.Size = new System.Drawing.Size(196, 31);
            this.lblloja.TabIndex = 0;
            this.lblloja.Text = "Loja de Games";
            this.lblloja.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblprod1
            // 
            this.lblprod1.AutoSize = true;
            this.lblprod1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprod1.Location = new System.Drawing.Point(37, 40);
            this.lblprod1.Name = "lblprod1";
            this.lblprod1.Size = new System.Drawing.Size(70, 17);
            this.lblprod1.TabIndex = 0;
            this.lblprod1.Text = "Produto 1";
            this.lblprod1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblprod2
            // 
            this.lblprod2.AutoSize = true;
            this.lblprod2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprod2.Location = new System.Drawing.Point(37, 92);
            this.lblprod2.Name = "lblprod2";
            this.lblprod2.Size = new System.Drawing.Size(70, 17);
            this.lblprod2.TabIndex = 0;
            this.lblprod2.Text = "Produto 2";
            this.lblprod2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblprod3
            // 
            this.lblprod3.AutoSize = true;
            this.lblprod3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprod3.Location = new System.Drawing.Point(37, 147);
            this.lblprod3.Name = "lblprod3";
            this.lblprod3.Size = new System.Drawing.Size(70, 17);
            this.lblprod3.TabIndex = 0;
            this.lblprod3.Text = "Produto 3";
            this.lblprod3.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblp1
            // 
            this.lblp1.AutoSize = true;
            this.lblp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblp1.Location = new System.Drawing.Point(203, 40);
            this.lblp1.Name = "lblp1";
            this.lblp1.Size = new System.Drawing.Size(57, 17);
            this.lblp1.TabIndex = 0;
            this.lblp1.Text = "Preço 1";
            this.lblp1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblp2
            // 
            this.lblp2.AutoSize = true;
            this.lblp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblp2.Location = new System.Drawing.Point(203, 92);
            this.lblp2.Name = "lblp2";
            this.lblp2.Size = new System.Drawing.Size(57, 17);
            this.lblp2.TabIndex = 0;
            this.lblp2.Text = "Preço 2";
            this.lblp2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblp3
            // 
            this.lblp3.AutoSize = true;
            this.lblp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblp3.Location = new System.Drawing.Point(203, 147);
            this.lblp3.Name = "lblp3";
            this.lblp3.Size = new System.Drawing.Size(57, 17);
            this.lblp3.TabIndex = 0;
            this.lblp3.Text = "Preço 3";
            this.lblp3.Click += new System.EventHandler(this.label1_Click);
            // 
            // bntcalc
            // 
            this.bntcalc.BackColor = System.Drawing.Color.CornflowerBlue;
            this.bntcalc.Location = new System.Drawing.Point(2, 398);
            this.bntcalc.Name = "bntcalc";
            this.bntcalc.Size = new System.Drawing.Size(792, 52);
            this.bntcalc.TabIndex = 3;
            this.bntcalc.Text = "CALCULAR";
            this.bntcalc.UseVisualStyleBackColor = false;
            this.bntcalc.Click += new System.EventHandler(this.bntcalc_Click);
            // 
            // lblparcela1
            // 
            this.lblparcela1.AutoSize = true;
            this.lblparcela1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela1.Location = new System.Drawing.Point(51, 48);
            this.lblparcela1.Name = "lblparcela1";
            this.lblparcela1.Size = new System.Drawing.Size(92, 17);
            this.lblparcela1.TabIndex = 0;
            this.lblparcela1.Text = "1 Parcela de:";
            this.lblparcela1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblparcela2
            // 
            this.lblparcela2.AutoSize = true;
            this.lblparcela2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela2.Location = new System.Drawing.Point(51, 80);
            this.lblparcela2.Name = "lblparcela2";
            this.lblparcela2.Size = new System.Drawing.Size(99, 17);
            this.lblparcela2.TabIndex = 0;
            this.lblparcela2.Text = "2 Parcelas de:";
            this.lblparcela2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblparcela3
            // 
            this.lblparcela3.AutoSize = true;
            this.lblparcela3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela3.Location = new System.Drawing.Point(51, 112);
            this.lblparcela3.Name = "lblparcela3";
            this.lblparcela3.Size = new System.Drawing.Size(99, 17);
            this.lblparcela3.TabIndex = 0;
            this.lblparcela3.Text = "3 Parcelas de:";
            this.lblparcela3.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblparcela4
            // 
            this.lblparcela4.AutoSize = true;
            this.lblparcela4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela4.Location = new System.Drawing.Point(51, 147);
            this.lblparcela4.Name = "lblparcela4";
            this.lblparcela4.Size = new System.Drawing.Size(99, 17);
            this.lblparcela4.TabIndex = 0;
            this.lblparcela4.Text = "4 Parcelas de:";
            this.lblparcela4.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblparcela5
            // 
            this.lblparcela5.AutoSize = true;
            this.lblparcela5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblparcela5.Location = new System.Drawing.Point(51, 182);
            this.lblparcela5.Name = "lblparcela5";
            this.lblparcela5.Size = new System.Drawing.Size(99, 17);
            this.lblparcela5.TabIndex = 0;
            this.lblparcela5.Text = "5 Parcelas de:";
            this.lblparcela5.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblresult1
            // 
            this.lblresult1.AutoSize = true;
            this.lblresult1.Location = new System.Drawing.Point(178, 50);
            this.lblresult1.Name = "lblresult1";
            this.lblresult1.Size = new System.Drawing.Size(10, 13);
            this.lblresult1.TabIndex = 1;
            this.lblresult1.Text = "-";
            // 
            // lblresult2
            // 
            this.lblresult2.AutoSize = true;
            this.lblresult2.Location = new System.Drawing.Point(178, 82);
            this.lblresult2.Name = "lblresult2";
            this.lblresult2.Size = new System.Drawing.Size(10, 13);
            this.lblresult2.TabIndex = 1;
            this.lblresult2.Text = "-";
            // 
            // lblresult3
            // 
            this.lblresult3.AutoSize = true;
            this.lblresult3.Location = new System.Drawing.Point(178, 114);
            this.lblresult3.Name = "lblresult3";
            this.lblresult3.Size = new System.Drawing.Size(10, 13);
            this.lblresult3.TabIndex = 1;
            this.lblresult3.Text = "-";
            // 
            // lblresult4
            // 
            this.lblresult4.AutoSize = true;
            this.lblresult4.Location = new System.Drawing.Point(178, 149);
            this.lblresult4.Name = "lblresult4";
            this.lblresult4.Size = new System.Drawing.Size(10, 13);
            this.lblresult4.TabIndex = 1;
            this.lblresult4.Text = "-";
            // 
            // lblresult5
            // 
            this.lblresult5.AutoSize = true;
            this.lblresult5.Location = new System.Drawing.Point(178, 184);
            this.lblresult5.Name = "lblresult5";
            this.lblresult5.Size = new System.Drawing.Size(10, 13);
            this.lblresult5.TabIndex = 1;
            this.lblresult5.Text = "-";
            // 
            // FmrQuestao3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntcalc);
            this.Controls.Add(this.pnldireita);
            this.Controls.Add(this.pnlesquerda);
            this.Controls.Add(this.pnlcabecalho);
            this.Name = "FmrQuestao3";
            this.Text = "FmrQuestao3";
            this.pnlcabecalho.ResumeLayout(false);
            this.pnlcabecalho.PerformLayout();
            this.pnlesquerda.ResumeLayout(false);
            this.pnlesquerda.PerformLayout();
            this.pnldireita.ResumeLayout(false);
            this.pnldireita.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlcabecalho;
        private System.Windows.Forms.TextBox txtprod1;
        private System.Windows.Forms.Panel pnlesquerda;
        private System.Windows.Forms.Panel pnldireita;
        private System.Windows.Forms.Label lblloja;
        private System.Windows.Forms.TextBox txtp3;
        private System.Windows.Forms.TextBox txtprod3;
        private System.Windows.Forms.TextBox txtp1;
        private System.Windows.Forms.TextBox txtp2;
        private System.Windows.Forms.TextBox txtprod2;
        private System.Windows.Forms.Label lblprod1;
        private System.Windows.Forms.Label lblp3;
        private System.Windows.Forms.Label lblprod3;
        private System.Windows.Forms.Label lblp2;
        private System.Windows.Forms.Label lblp1;
        private System.Windows.Forms.Label lblprod2;
        private System.Windows.Forms.Label lblparcela5;
        private System.Windows.Forms.Label lblparcela4;
        private System.Windows.Forms.Label lblparcela3;
        private System.Windows.Forms.Label lblparcela2;
        private System.Windows.Forms.Label lblparcela1;
        private System.Windows.Forms.Button bntcalc;
        private System.Windows.Forms.Label lblresult5;
        private System.Windows.Forms.Label lblresult4;
        private System.Windows.Forms.Label lblresult3;
        private System.Windows.Forms.Label lblresult2;
        private System.Windows.Forms.Label lblresult1;
    }
}