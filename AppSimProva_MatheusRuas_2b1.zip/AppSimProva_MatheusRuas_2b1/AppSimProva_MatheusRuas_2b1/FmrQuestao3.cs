﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_MatheusRuas_2b1
{
    public partial class FmrQuestao3 : Form
    {
        public FmrQuestao3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bntcalc_Click(object sender, EventArgs e)
        {

                //Pegar dados datela
                float lblp1 = float .Parse(txtp1)
        }
    }
}
