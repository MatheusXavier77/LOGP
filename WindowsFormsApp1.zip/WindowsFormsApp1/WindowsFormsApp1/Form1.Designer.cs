﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.bntsoma = new System.Windows.Forms.Button();
            this.bntmenos = new System.Windows.Forms.Button();
            this.bntmult = new System.Windows.Forms.Button();
            this.bntdiv = new System.Windows.Forms.Button();
            this.bntenviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(56, 49);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(315, 51);
            this.txt1.TabIndex = 0;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(56, 165);
            this.txt2.Multiline = true;
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(315, 51);
            this.txt2.TabIndex = 0;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(53, 33);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(83, 17);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Número 1:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(53, 149);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(83, 17);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Número 2:";
            // 
            // bntsoma
            // 
            this.bntsoma.Location = new System.Drawing.Point(56, 232);
            this.bntsoma.Name = "bntsoma";
            this.bntsoma.Size = new System.Drawing.Size(152, 57);
            this.bntsoma.TabIndex = 2;
            this.bntsoma.Text = "+";
            this.bntsoma.UseVisualStyleBackColor = true;
            // 
            // bntmenos
            // 
            this.bntmenos.Location = new System.Drawing.Point(214, 232);
            this.bntmenos.Name = "bntmenos";
            this.bntmenos.Size = new System.Drawing.Size(157, 57);
            this.bntmenos.TabIndex = 2;
            this.bntmenos.Text = "-";
            this.bntmenos.UseVisualStyleBackColor = true;
            // 
            // bntmult
            // 
            this.bntmult.Location = new System.Drawing.Point(56, 295);
            this.bntmult.Name = "bntmult";
            this.bntmult.Size = new System.Drawing.Size(152, 61);
            this.bntmult.TabIndex = 2;
            this.bntmult.Text = "*";
            this.bntmult.UseVisualStyleBackColor = true;
            // 
            // bntdiv
            // 
            this.bntdiv.Location = new System.Drawing.Point(214, 295);
            this.bntdiv.Name = "bntdiv";
            this.bntdiv.Size = new System.Drawing.Size(157, 61);
            this.bntdiv.TabIndex = 2;
            this.bntdiv.Text = "/";
            this.bntdiv.UseVisualStyleBackColor = true;
            // 
            // bntenviar
            // 
            this.bntenviar.Location = new System.Drawing.Point(56, 362);
            this.bntenviar.Name = "bntenviar";
            this.bntenviar.Size = new System.Drawing.Size(315, 57);
            this.bntenviar.TabIndex = 3;
            this.bntenviar.Text = "Enviar";
            this.bntenviar.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntenviar);
            this.Controls.Add(this.bntdiv);
            this.Controls.Add(this.bntmult);
            this.Controls.Add(this.bntmenos);
            this.Controls.Add(this.bntsoma);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Button bntsoma;
        private System.Windows.Forms.Button bntmenos;
        private System.Windows.Forms.Button bntmult;
        private System.Windows.Forms.Button bntdiv;
        private System.Windows.Forms.Button bntenviar;
    }
}

