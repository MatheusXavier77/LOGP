﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bntenviar_click(object sender, EventArgs e)
        {

            int varInteiro = int.Parse(txt1.Text);
            float varDecimal = float.Parse(txt2.Text);
            float resultado;

            //Soma
            resultado = varInteiro + varDecimal + 3;
            MessageBox.Show("Soma: " + resultado);

            //Subtração
            resultado = varInteiro - varDecimal;
            MessageBox.Show("Divisão: " + resultado);

            //Multiplicação
            resultado = varInteiro * varDecimal;
            MessageBox.Show("Multiplicação: " + resultado);




        }
    }
}

